import { Book, Briefcase, Building2, GraduationCap, Layers, User, Award } from 'lucide-react';

export const personalInfo = {
  name: "Inodee Fernando",
  title: "Urban Planner | Designer | Researcher",
  contact: {
    phone: "+65 8642 5368",
    email: "inodee.fernando@gmail.com",
    location: "Singapore / Sri Lanka"
  },
  socials: {
    linkedin: "#", // Placeholder as it wasn't explicitly in the text, but good to have structure
  }
};

export const about = {
  title: "About Me",
  content: [
    "I'm currently a final-year undergraduate at the University of Moratuwa, renowned as the best technological university in Sri Lanka. My undergraduate degree, B.Sc. (Hons) in Town and Country Planning, provided me with a strong foundation in diverse arenas such as urban and rural development, urban regeneration, environmental planning, economics, transport planning, GIS and many more.",
    "From my school days, I've been interested in multiple subjects, though at times, I struggled to see the connections between them. As an urban planning student, public speaker, organizer, chorister, instrumentalist, graphic designer, avid traveller, and tech enthusiast, my passions seemed unrelated. But these have collectively shaped me into a creative problem solver with a strong analytical mindset.",
    "I am pursuing a Master's in Urban Science Policy & Planning at Singapore University of Technology and Design (2025-2026). My vision is to contribute to impactful projects that can serve thousands—perhaps even generations."
  ]
};

export const education = [
  {
    institution: "Singapore University Technology and Design",
    period: "2025 - 2026",
    degree: "Master's in Urban Science Policy & Planning",
    details: ["Urban Planning", "Data methods and analysis", "GIS", "Urban Psychology"]
  },
  {
    institution: "University of Moratuwa | Sri Lanka",
    period: "2021 – 2025",
    degree: "B.Sc. (Hons) in Town and Country Planning",
    details: [
      "Class Obtained: First Class",
      "Dean's List Award: Semesters 1, 5, 6, 7",
      "CGPA 3.81 / 4.20 (Upto Semester 6)",
      "Focus: Urban Planning, EMS, Computational Urban Science, GIS, GeoAi, Economics, Project Management"
    ]
  },
  {
    institution: "Chartered Institute of Management Accountants (CIMA)",
    period: "2019 - 2022",
    degree: "CIMA Diploma in Management Accounting",
    details: ["Management Accounting", "Financial Reporting", "Business Economics", "Business Law"]
  },
  {
    institution: "Holy Cross College Gampaha",
    period: "2006 - 2019",
    degree: "Primary & Secondary Education",
    details: [
      "Advanced Level (2019): 9As, Z Score – 1.692 (Combined Maths, Physics, ICT)",
      "Ordinary Level (2016): 9As"
    ]
  }
];

export const experience = [
  {
    role: "Student Research Assistant",
    company: "LKYCIC | SUTD",
    period: "Oct 2025 – Jan 2026",
    description: "Transcribing work for the project 'Building Our Neighbourhood Dynamics (BOND): A Social-Spatial Study of Diverse Housing Typologies in Singapore'."
  },
  {
    role: "Project Executive – Interior Fitout (New Retail Stores)",
    company: "Keells Supermarket Chain | John Keells Holdings",
    period: "Jan 2025 - Present",
    description: "Managed 7 new outlet construction projects. Coordinated with design, procurement, and construction teams. Aligned brand guidelines, prepared tender submissions, and developed tracking systems using Power Automate and Power BI."
  },
  {
    role: "Intern - Planning & Monitoring for Civil Projects",
    company: "Advantis Engineering & Construction",
    period: "May 2024 - July 2024",
    description: "Prepared project timelines, monitored progress for Colombo Port East Container Terminal Fencing and Norochcholi Coal Yard Extension. Developed progress monitoring dashboards."
  },
  {
    role: "Research Intern",
    company: "Disaster Management Centre (Sri Lanka)",
    period: "April 2024",
    description: "Developed a comprehensive database of early warnings (2018-2023) for floods and landslides. Assessed effectiveness of early warnings."
  },
  {
    role: "Qualified Tutor - Mathematics UK & USA",
    company: "Third Space Global",
    period: "Nov 2023 – July 2025",
    description: "Tutored Mathematics to native English speaking primary students in UK / USA. Student-centred one-to-one online tutoring."
  },
  {
    role: "Volunteer - OSM Data Mapping",
    company: "World Vision Lanka",
    period: "Oct 2023 - Nov 2023",
    description: "Anticipatory Action (AA) for Disaster Mitigation project. Mapping and solving errors in OSM Data using JOSM and QGIS."
  },
  {
    role: "Digital Marketing Brand Manager",
    company: "Group TAC (Pvt) Ltd",
    period: "Aug 2020 – Apr 2022",
    description: "Managed digital marketing and brand presence."
  }
];

export const projects = [
  {
    title: "Assessing Water Quality of Negombo Lagoon",
    category: "Academic / Environmental",
    tools: ["Sentinel-2", "SNAP", "Remote Sensing"],
    description: "Assessed water quality parameters using satellite images (2016-2020). Compared indices like MCI, Near-Infrared, and TSM to understand seasonal variations and impact of climatic conditions."
  },
  {
    title: "NDVI Analysis using Satellite Images",
    category: "Academic / GIS",
    tools: ["Google Earth Engine", "Landsat 8", "Javascript"],
    description: "Performed NDVI analysis for the sensing period Aug-Nov 2018 to visualize vegetation health and cover."
  },
  {
    title: "Urban Development Plan for Dambulla",
    category: "Urban Planning",
    tools: ["Planning Process", "Stakeholder Analysis", "Strategic Planning"],
    description: "Prepared a development plan for a popular tourist destination. Identified misfits (Land Fragmentation, Human-Elephant Conflict) and proposed a zoning plan including Adventure Tourism, Mixed Development, and Cultural zones."
  },
  {
    title: "Keells Super Markets Catchment Analysis",
    category: "Data Analysis / GIS",
    tools: ["Python", "Google Maps API", "Folium", "Pandas"],
    description: "Identified areas within 5km of current Keells Super Markets. Used Google API to fetch location data and visualized buffer rings using Folium to aid in catchment analysis."
  },
  {
    title: "Ja-Ela Public Market Regeneration",
    category: "Urban Design",
    tools: ["Urban Regeneration", "Project Proposal"],
    description: "Project proposal and identification for the regeneration of the Ja-Ela Public Market to improve urban utility and aesthetics."
  }
];

export const extracurricular = [
  {
    organization: "Gavel Club of University of Moratuwa",
    role: "Vice President in Public Relations (2023/24)",
    period: "2021 - 2025",
    details: "Managed PR function, brand management, and led the design team. Previously Project Co-chair for Speech Olympiad XV and Club Orientation."
  },
  {
    organization: "Town & Country Planning Students' Society (TCPSS)",
    role: "Committee Member",
    period: "2022 - 2025",
    details: "Department Coordinator at EXMO Exhibition. Event Coordinator at Sankalana’23."
  },
  {
    organization: "American Planners’ Association (APA)",
    role: "Student Ambassador",
    period: "2023 - 2024",
    details: "City Planning and Management Division."
  },
  {
    organization: "Catholic Students’ Movement",
    role: "Vice President - Multimedia & Graphics",
    period: "2022/23",
    details: "Carols Coordinator (2022)."
  },
  {
    organization: "Sakura Science Club, Japan",
    role: "Alumni Member",
    period: "2018 - Present",
    details: "Participated as an Exchange Student in the SAKURA Exchange Program in Science at Saitama University (2018)."
  }
];

export const skills = {
  software: ["QGIS", "AutoCAD", "JOSM", "SNAP (Satellite Analysis)", "SPSS", "ArcGIS", "MS Projects", "Power BI", "Adobe Photoshop", "Premier Pro", "Illustrator"],
  programming: ["Python", "R Programming", "Javascript"],
  soft: ["Public Speaking", "Critical Thinking", "Team Player", "Leadership", "Graphic Design"],
  languages: ["English (Fluent)", "Sinhala (Native)"]
};
