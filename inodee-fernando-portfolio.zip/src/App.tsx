/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import Navbar from './components/Navbar';
import Section from './components/Section';
import PixelBuilding from './components/PixelBuilding';
import { personalInfo, about, education, experience, projects, extracurricular, skills } from './data';
import { MapPin, Mail, Phone, ExternalLink, Download, Calendar, Briefcase, GraduationCap, Award } from 'lucide-react';

export default function App() {
  return (
    <div className="relative min-h-screen">
      <Navbar />
      <PixelBuilding />

      {/* Hero Section */}
      <section className="h-screen flex flex-col justify-center items-start px-6 md:px-24 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-xl md:text-2xl text-earth-medium mb-4 font-typewriter">Hello, I am</h2>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-earth-dark mb-6 font-typewriter">
            {personalInfo.name}
          </h1>
          <p className="text-xl md:text-3xl text-earth-olive mb-8 max-w-2xl">
            {personalInfo.title}
          </p>
          
          <div className="flex flex-col md:flex-row gap-4 md:gap-8 text-earth-medium mb-10">
            <div className="flex items-center gap-2">
              <MapPin size={20} />
              <span>{personalInfo.contact.location}</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail size={20} />
              <a href={`mailto:${personalInfo.contact.email}`} className="hover:text-earth-accent transition-colors">
                {personalInfo.contact.email}
              </a>
            </div>
            <div className="flex items-center gap-2">
              <Phone size={20} />
              <span>{personalInfo.contact.phone}</span>
            </div>
          </div>

          <motion.a
            href="#about"
            className="inline-block px-8 py-3 bg-earth-dark text-earth-beige font-typewriter text-lg rounded-sm border-2 border-earth-dark hover:bg-transparent hover:text-earth-dark transition-all"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Explore My Work
          </motion.a>
        </motion.div>

        <motion.div 
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-earth-medium flex flex-col items-center gap-2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <span className="font-typewriter text-sm">Scroll to Build</span>
          <Download className="rotate-180" size={24} />
        </motion.div>
      </section>

      {/* About Section */}
      <Section id="about" title={about.title} className="bg-earth-sand/20">
        <div className="grid md:grid-cols-3 gap-12">
          <div className="md:col-span-2 space-y-6 text-lg leading-relaxed text-earth-dark/90 text-justify">
            {about.content.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
            
            <div className="mt-8">
              <h3 className="text-2xl font-typewriter mb-4 text-earth-accent">Skills</h3>
              <div className="flex flex-wrap gap-2">
                {[...skills.software, ...skills.programming, ...skills.soft].map((skill) => (
                  <span key={skill} className="px-3 py-1 bg-earth-olive/10 border border-earth-olive/30 text-earth-dark rounded-full text-sm">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
          
          <div className="md:col-span-1">
            {/* Placeholder for Image if user had one, using a stylized box for now */}
            <div className="w-full aspect-[3/4] bg-earth-medium/10 border-4 border-earth-dark p-4 relative">
              <div className="absolute inset-0 border-2 border-dashed border-earth-accent m-2 opacity-50"></div>
              <div className="h-full w-full flex items-center justify-center text-earth-medium/50 font-typewriter text-center">
                [Profile Image Placeholder]
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* Education Section */}
      <Section id="education" title="Education">
        <div className="space-y-12">
          {education.map((edu, index) => (
            <div key={index} className="relative pl-8 border-l-2 border-earth-medium/30">
              <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-earth-accent"></div>
              <div className="mb-2 flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <h3 className="text-2xl font-bold text-earth-dark">{edu.institution}</h3>
                <span className="text-earth-olive font-typewriter bg-earth-olive/10 px-3 py-1 rounded-md text-sm mt-2 sm:mt-0 w-fit">
                  {edu.period}
                </span>
              </div>
              <h4 className="text-xl text-earth-medium mb-4 font-semibold">{edu.degree}</h4>
              <ul className="list-disc list-inside space-y-2 text-earth-dark/80">
                {edu.details.map((detail, idx) => (
                  <li key={idx}>{detail}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Section>

      {/* Experience Section */}
      <Section id="experience" title="Experience" className="bg-earth-sand/20">
        <div className="grid gap-8">
          {experience.map((exp, index) => (
            <motion.div 
              key={index}
              className="bg-earth-beige p-6 border-l-4 border-earth-olive shadow-sm hover:shadow-md transition-shadow"
              whileHover={{ x: 10 }}
            >
              <div className="flex flex-col md:flex-row md:justify-between md:items-start mb-4">
                <div>
                  <h3 className="text-xl font-bold text-earth-dark">{exp.role}</h3>
                  <p className="text-earth-medium font-medium">{exp.company}</p>
                </div>
                <div className="flex items-center gap-2 text-earth-olive font-typewriter text-sm mt-2 md:mt-0">
                  <Calendar size={16} />
                  <span>{exp.period}</span>
                </div>
              </div>
              <p className="text-earth-dark/80 leading-relaxed">
                {exp.description}
              </p>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Projects Section */}
      <Section id="projects" title="Projects">
        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.div 
              key={index}
              className="group relative bg-white border-2 border-earth-dark p-6 overflow-hidden"
              whileHover={{ y: -5 }}
            >
              <div className="absolute top-0 right-0 bg-earth-accent text-white text-xs px-2 py-1 font-typewriter">
                {project.category}
              </div>
              <h3 className="text-2xl font-bold text-earth-dark mb-3 group-hover:text-earth-accent transition-colors">
                {project.title}
              </h3>
              <div className="flex flex-wrap gap-2 mb-4">
                {project.tools.map((tool) => (
                  <span key={tool} className="text-xs font-mono bg-earth-medium/10 text-earth-medium px-2 py-1 rounded">
                    {tool}
                  </span>
                ))}
              </div>
              <p className="text-earth-dark/80 mb-4">
                {project.description}
              </p>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Extra Curricular Section */}
      <Section id="activities" title="Extra Curricular" className="bg-earth-sand/20">
        <div className="grid md:grid-cols-2 gap-6">
          {extracurricular.map((activity, index) => (
            <div key={index} className="flex gap-4 items-start">
              <div className="mt-1 min-w-[40px] h-10 bg-earth-dark text-earth-beige flex items-center justify-center rounded-full">
                <Award size={20} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-earth-dark">{activity.organization}</h3>
                <p className="text-earth-accent font-medium">{activity.role}</p>
                <p className="text-sm text-earth-medium mb-2 font-typewriter">{activity.period}</p>
                <p className="text-earth-dark/70 text-sm">{activity.details}</p>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* Footer */}
      <footer className="bg-earth-dark text-earth-beige py-12 px-6 text-center relative z-10">
        <h2 className="text-3xl font-typewriter mb-6">Let's Build Something Together</h2>
        <div className="flex justify-center gap-8 mb-8">
          <a href={`mailto:${personalInfo.contact.email}`} className="hover:text-earth-accent transition-colors flex items-center gap-2">
            <Mail /> Email Me
          </a>
          {/* Add LinkedIn or other socials here */}
        </div>
        <p className="text-earth-sand/50 text-sm font-typewriter">
          © {new Date().getFullYear()} {personalInfo.name}. All rights reserved.
        </p>
      </footer>
    </div>
  );
}

