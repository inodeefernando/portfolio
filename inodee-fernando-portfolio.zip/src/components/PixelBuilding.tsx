import { motion, useScroll, useTransform } from 'motion/react';
import { useEffect, useState } from 'react';

export default function PixelBuilding() {
  const { scrollYProgress } = useScroll();
  const [floors, setFloors] = useState<number[]>([]);

  // Generate a static number of floors based on viewport height roughly
  useEffect(() => {
    const floorCount = 20; 
    setFloors(Array.from({ length: floorCount }, (_, i) => i));
  }, []);

  // Map scroll progress to the number of visible floors
  // We want the building to "grow" from bottom to top as we scroll down.
  // So at scroll 0, maybe 1 floor. At scroll 1, all floors.
  const visibleFloors = useTransform(scrollYProgress, [0, 1], [1, 20]);
  
  return (
    <div className="pixel-building-container hidden lg:flex opacity-20 lg:opacity-40">
      {floors.map((floor) => (
        <Floor key={floor} index={floor} visibleFloors={visibleFloors} />
      ))}
      <div className="w-full h-4 bg-earth-dark mt-auto"></div> {/* Foundation */}
    </div>
  );
}

function Floor({ index, visibleFloors }: { index: number; visibleFloors: any }) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const unsubscribe = visibleFloors.on("change", (latest: number) => {
      setIsVisible(index < latest);
    });
    return () => unsubscribe();
  }, [visibleFloors, index]);

  return (
    <motion.div
      className="pixel-block h-16 flex justify-around items-center transition-opacity duration-300"
      style={{ 
        opacity: isVisible ? 1 : 0,
        y: isVisible ? 0 : 50
      }}
    >
      <div className="pixel-window left-[10%]"></div>
      <div className="pixel-window left-[40%]"></div>
      <div className="pixel-window left-[70%]"></div>
    </motion.div>
  );
}
